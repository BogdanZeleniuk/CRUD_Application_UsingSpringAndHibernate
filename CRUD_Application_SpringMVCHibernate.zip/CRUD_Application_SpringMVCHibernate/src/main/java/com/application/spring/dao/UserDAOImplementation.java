package com.application.spring.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.application.spring.model.User;

@Repository
public class UserDAOImplementation implements UserDAO {

	private static final Logger logger = LoggerFactory.getLogger(UserDAOImplementation.class);
	private SessionFactory sessionfactory; 
	
	public SessionFactory getSessionfactory() {
		return sessionfactory;
	}

	public void setSessionfactory(SessionFactory sessionfactory) {
		this.sessionfactory = sessionfactory;
	}

	@Override
	public void addUser(User u) {
		Session session = this.sessionfactory.getCurrentSession();
		session.persist(u);
		logger.info("User was added successfully");
		logger.info("User details: "+u);
	}

	@Override
	public void updateUser(User u) {
		Session session = this.sessionfactory.getCurrentSession();
		session.update(u);
		logger.info("User was updated successfully");
		logger.info("User details: "+u);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<User> listUsers() {
		Session session = this.sessionfactory.getCurrentSession();
		List<User> usersList = (List<User>) session.createQuery("from Users_list").list();
		for(User u : usersList){
			logger.info("User list: "+u);
		}
		return usersList;
	}

	@Override
	public User getUserById(int id) {
		Session session = this.sessionfactory.getCurrentSession();
		User u = (User) session.load(User.class, new Integer (id));
		logger.info("User was loadded successfully");
		logger.info("User details: "+u);
		return u;
	}

	@Override
	public void removeUser(int id) {
		Session session = this.sessionfactory.getCurrentSession();
		User u = (User) session.load(User.class, new Integer (id));
		if(u!=null){
			session.delete(u);
		}
		logger.info("User was deleted successfylly");
		logger.info("User details: "+u);
	}

}
